// models/Registration.js
// This defines the shape of a Registration document in MongoDB
// A Registration links a User to an Event (like a ticket)

const mongoose = require("mongoose");
const { v4: uuidv4 } = require("uuid");

const registrationSchema = new mongoose.Schema(
  {
    // Which user registered
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Which event they registered for
    event: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      required: true,
    },

    // Unique ticket ID generated automatically (used for check-in)
    ticketId: {
      type: String,
      unique: true,
      default: () => uuidv4(), // generates a unique ID like "a1b2-c3d4-..."
    },

    // Has the attendee checked in at the event?
    checkInStatus: {
      type: Boolean,
      default: false, // false = not checked in yet
    },

    // Allow only one registration per user per event
    // This is enforced by the compound index below
  },
  {
    timestamps: true,
  }
);

// Compound index: prevents a user from registering for the same event twice
registrationSchema.index({ user: 1, event: 1 }, { unique: true });

const Registration = mongoose.model("Registration", registrationSchema);

module.exports = Registration;
