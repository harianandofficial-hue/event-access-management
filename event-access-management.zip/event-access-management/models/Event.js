// models/Event.js
// This defines the shape of an Event document in MongoDB

const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Event title is required"],
      trim: true,
    },

    description: {
      type: String,
      required: [true, "Event description is required"],
    },

    date: {
      type: Date,
      required: [true, "Event date is required"],
    },

    venue: {
      type: String,
      required: [true, "Event venue is required"],
    },

    // Max number of people who can register
    capacity: {
      type: Number,
      default: 100,
    },

    // Reference to the User (organizer) who created this event
    organizer: {
      type: mongoose.Schema.Types.ObjectId, // links to a User document
      ref: "User",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const Event = mongoose.model("Event", eventSchema);

module.exports = Event;
