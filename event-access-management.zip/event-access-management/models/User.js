// models/User.js
// This defines the shape of a User document in MongoDB

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true, // removes extra spaces
    },

    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true, // no two users can have same email
      lowercase: true,
      trim: true,
    },

    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: 6,
    },

    // Role-Based Access Control (RBAC)
    // Each user has one role: admin, organizer, or user
    role: {
      type: String,
      enum: ["admin", "organizer", "user"], // only these 3 values allowed
      default: "user", // new accounts are regular users by default
    },
  },
  {
    // Automatically adds createdAt and updatedAt fields
    timestamps: true,
  }
);

// ---- MIDDLEWARE (runs before saving) ----
// Hash the password before saving to database
userSchema.pre("save", async function (next) {
  // Only hash if password was changed (avoid re-hashing on profile update)
  if (!this.isModified("password")) return next();

  // bcrypt salt rounds = 10 (higher = more secure but slower)
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// ---- METHODS ----
// Compare entered password with the hashed password in DB
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model("User", userSchema);

module.exports = User;
