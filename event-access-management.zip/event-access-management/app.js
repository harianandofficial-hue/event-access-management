// app.js
// This is where we configure the Express application
// We set up middlewares, routes, and error handling here

const express = require("express");
const { errorHandler, notFound } = require("./middleware/errorMiddleware");
const setupSwagger = require("./config/swagger");

const app = express();

// ---- BUILT-IN MIDDLEWARES ----
// Parse incoming JSON request bodies
app.use(express.json());

// Parse URL-encoded form data
app.use(express.urlencoded({ extended: false }));

// ---- SWAGGER DOCUMENTATION ----
setupSwagger(app);

// ---- HEALTH CHECK ROUTE ----
// Simple route to check if the server is running
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Event Access Management API is running 🚀",
    docs: "http://localhost:5000/api-docs",
  });
});

// ---- API ROUTES ----
// Each route group has a base path prefix
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/events", require("./routes/eventRoutes"));
app.use("/api/registrations", require("./routes/registrationRoutes"));
app.use("/api/admin", require("./routes/adminRoutes"));

// ---- ERROR HANDLING MIDDLEWARES ----
// These must come AFTER all routes
app.use(notFound);      // Handles unknown routes (404)
app.use(errorHandler);  // Handles all thrown errors (500, etc.)

module.exports = app;
