// utils/sendResponse.js
// Helper function for sending consistent API responses
// Every response follows the same structure: { success, message, data }

const sendResponse = (res, statusCode, success, message, data = null) => {
  const response = { success, message };

  // Only include data if it's provided
  if (data !== null) {
    response.data = data;
  }

  return res.status(statusCode).json(response);
};

module.exports = sendResponse;
