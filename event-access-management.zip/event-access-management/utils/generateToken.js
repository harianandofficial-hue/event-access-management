// utils/generateToken.js
// Helper function to generate a JWT token for a user

const jwt = require("jsonwebtoken");

const generateToken = (userId, role) => {
  // jwt.sign() creates the token
  // Payload: data we embed inside the token (userId and role)
  // Secret: used to sign and verify the token
  // Options: when the token expires
  return jwt.sign(
    { id: userId, role: role }, // payload
    process.env.JWT_SECRET,     // secret key from .env
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" } // expiry
  );
};

module.exports = generateToken;
