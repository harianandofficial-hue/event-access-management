// config/swagger.js
// This file sets up Swagger for API documentation
// Visit http://localhost:5000/api-docs to view the docs

const swaggerJsdoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

// Swagger definition — describes our API
const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Event Access Management API",
      version: "1.0.0",
      description:
        "A beginner-friendly backend API for managing event access, registrations, and attendees.",
    },
    servers: [
      {
        url: "http://localhost:5000/api",
        description: "Development Server",
      },
    ],
    components: {
      securitySchemes: {
        // We use Bearer token (JWT) for authentication
        BearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
        },
      },
    },
    security: [{ BearerAuth: [] }],
  },
  // Tell swagger-jsdoc where to find our route files with JSDoc comments
  apis: ["./routes/*.js"],
};

const swaggerSpec = swaggerJsdoc(options);

// Function to set up swagger in our Express app
const setupSwagger = (app) => {
  app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  console.log("📄 Swagger Docs available at: http://localhost:5000/api-docs");
};

module.exports = setupSwagger;
