# 🎫 Event Access Management System

A beginner-friendly backend REST API built with **Node.js**, **Express**, **MongoDB**, and **JWT Authentication**.

---

## 📦 Tech Stack

| Tool | Purpose |
|------|---------|
| Node.js | JavaScript runtime |
| Express.js | Web framework |
| MongoDB | Database |
| Mongoose | MongoDB object modeling |
| JWT | Authentication tokens |
| bcryptjs | Password hashing |
| dotenv | Environment variables |
| express-validator | Input validation |
| swagger-ui-express | API documentation |
| uuid | Unique ticket ID generation |

---

## 🚀 Getting Started

### 1. Clone the project
```bash
git clone <repo-url>
cd event-access-management
```

### 2. Install dependencies
```bash
npm install
```

### 3. Set up environment variables
```bash
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
```

### 4. Run the server
```bash
# Development (with auto-reload)
npm run dev

# Production
npm start
```

### 5. Open API Docs
Visit: **http://localhost:5000/api-docs**

---

## 🗂️ Folder Structure

```
event-access-management/
├── controllers/          # Business logic
│   ├── authController.js
│   ├── eventController.js
│   ├── registrationController.js
│   └── adminController.js
├── models/               # MongoDB schemas
│   ├── User.js
│   ├── Event.js
│   └── Registration.js
├── routes/               # URL endpoints
│   ├── authRoutes.js
│   ├── eventRoutes.js
│   ├── registrationRoutes.js
│   └── adminRoutes.js
├── middleware/           # Reusable middleware
│   ├── authMiddleware.js
│   ├── roleMiddleware.js
│   ├── errorMiddleware.js
│   └── validationMiddleware.js
├── config/               # Configuration files
│   ├── db.js
│   └── swagger.js
├── utils/                # Helper functions
│   ├── generateToken.js
│   └── sendResponse.js
├── app.js                # Express app setup
├── server.js             # Entry point
├── .env.example          # Sample environment file
└── README.md
```

---

## 👥 Roles & Permissions

| Action | User | Organizer | Admin |
|--------|------|-----------|-------|
| Register / Login | ✅ | ✅ | ✅ |
| View all events | ✅ | ✅ | ✅ |
| Create event | ❌ | ✅ | ✅ |
| Update/Delete own event | ❌ | ✅ | ✅ |
| Update/Delete any event | ❌ | ❌ | ✅ |
| Register for event | ✅ | ✅ | ✅ |
| View own registrations | ✅ | ✅ | ✅ |
| View event attendees | ❌ | ✅ (own) | ✅ |
| Verify tickets (check-in) | ❌ | ✅ | ✅ |
| Manage users | ❌ | ❌ | ✅ |

---

## 🌐 API Endpoints

### Auth
| Method | URL | Description | Access |
|--------|-----|-------------|--------|
| POST | `/api/auth/register` | Register new user | Public |
| POST | `/api/auth/login` | Login and get token | Public |
| GET | `/api/auth/me` | Get own profile | Private |

### Events
| Method | URL | Description | Access |
|--------|-----|-------------|--------|
| GET | `/api/events` | Get all events | Public |
| GET | `/api/events/:id` | Get single event | Public |
| POST | `/api/events` | Create event | Organizer/Admin |
| PUT | `/api/events/:id` | Update event | Organizer/Admin |
| DELETE | `/api/events/:id` | Delete event | Organizer/Admin |

### Registrations
| Method | URL | Description | Access |
|--------|-----|-------------|--------|
| POST | `/api/registrations/:eventId` | Register for event | Private |
| GET | `/api/registrations/my` | Get my registrations | Private |
| DELETE | `/api/registrations/:id` | Cancel registration | Private |
| GET | `/api/registrations/event/:eventId` | Get event attendees | Organizer/Admin |
| PATCH | `/api/registrations/verify/:ticketId` | Verify ticket (check-in) | Organizer/Admin |

### Admin
| Method | URL | Description | Access |
|--------|-----|-------------|--------|
| GET | `/api/admin/users` | Get all users | Admin |
| PATCH | `/api/admin/users/:id/role` | Update user role | Admin |
| DELETE | `/api/admin/users/:id` | Delete user | Admin |

---

## 📋 Response Format

Every API response follows this consistent structure:

```json
{
  "success": true,
  "message": "Event created successfully",
  "data": {}
}
```

---

## 🔐 Authentication

1. Register or login to get a **JWT token**
2. Include the token in the **Authorization** header for protected routes:
```
Authorization: Bearer <your_token_here>
```

---

## 🎫 How Ticket Verification Works

1. User registers for an event → gets a **unique ticketId** (UUID)
2. At the event, organizer/admin hits: `PATCH /api/registrations/verify/:ticketId`
3. If ticket is valid and not used → **check-in successful** ✅
4. If ticket already used → **rejected** ❌

---

## 💡 Tips for Beginners

- Use **Postman** or **Thunder Client** to test the APIs
- Visit **/api-docs** for interactive Swagger documentation
- Check the `.env.example` file for required environment variables
- MongoDB can be run locally or use **MongoDB Atlas** (free cloud option)
