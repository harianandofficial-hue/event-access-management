// controllers/eventController.js
// Handles all event CRUD operations

const Event = require("../models/Event");
const sendResponse = require("../utils/sendResponse");

// -----------------------------------------------
// @desc    Create a new event
// @route   POST /api/events
// @access  Private (Admin, Organizer)
// -----------------------------------------------
const createEvent = async (req, res, next) => {
  try {
    const { title, description, date, venue, capacity } = req.body;

    // Set the organizer to the currently logged-in user
    const event = await Event.create({
      title,
      description,
      date,
      venue,
      capacity,
      organizer: req.user._id,
    });

    return sendResponse(res, 201, true, "Event created successfully", event);
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Get all events
// @route   GET /api/events
// @access  Public
// -----------------------------------------------
const getAllEvents = async (req, res, next) => {
  try {
    // Populate organizer info — replaces the ObjectId with actual user data
    const events = await Event.find()
      .populate("organizer", "name email") // show only name and email
      .sort({ date: 1 }); // sort by upcoming events first

    return sendResponse(res, 200, true, "Events fetched successfully", events);
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Get a single event by ID
// @route   GET /api/events/:id
// @access  Public
// -----------------------------------------------
const getEventById = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id).populate(
      "organizer",
      "name email"
    );

    if (!event) {
      return sendResponse(res, 404, false, "Event not found");
    }

    return sendResponse(res, 200, true, "Event fetched successfully", event);
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Update an event
// @route   PUT /api/events/:id
// @access  Private (Admin or the Organizer who created it)
// -----------------------------------------------
const updateEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);

    if (!event) {
      return sendResponse(res, 404, false, "Event not found");
    }

    // Only allow the organizer who created it OR an admin to update
    if (
      event.organizer.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return sendResponse(
        res,
        403,
        false,
        "You are not authorized to update this event"
      );
    }

    // Update the event fields
    const updatedEvent = await Event.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true } // return updated doc and run schema validators
    );

    return sendResponse(
      res,
      200,
      true,
      "Event updated successfully",
      updatedEvent
    );
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Delete an event
// @route   DELETE /api/events/:id
// @access  Private (Admin or the Organizer who created it)
// -----------------------------------------------
const deleteEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);

    if (!event) {
      return sendResponse(res, 404, false, "Event not found");
    }

    // Only the organizer who created it OR an admin can delete
    if (
      event.organizer.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return sendResponse(
        res,
        403,
        false,
        "You are not authorized to delete this event"
      );
    }

    await event.deleteOne();

    return sendResponse(res, 200, true, "Event deleted successfully");
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createEvent,
  getAllEvents,
  getEventById,
  updateEvent,
  deleteEvent,
};
