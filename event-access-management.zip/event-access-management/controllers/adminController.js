// controllers/adminController.js
// Admin-only operations: manage users

const User = require("../models/User");
const sendResponse = require("../utils/sendResponse");

// -----------------------------------------------
// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin only)
// -----------------------------------------------
const getAllUsers = async (req, res, next) => {
  try {
    // Exclude password field from results
    const users = await User.find().select("-password").sort({ createdAt: -1 });

    return sendResponse(res, 200, true, "Users fetched successfully", users);
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Update a user's role
// @route   PATCH /api/admin/users/:id/role
// @access  Private (Admin only)
// -----------------------------------------------
const updateUserRole = async (req, res, next) => {
  try {
    const { role } = req.body;

    // Validate the role value
    if (!["admin", "organizer", "user"].includes(role)) {
      return sendResponse(
        res,
        400,
        false,
        "Invalid role. Choose: admin, organizer, or user"
      );
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role },
      { new: true }
    ).select("-password");

    if (!user) {
      return sendResponse(res, 404, false, "User not found");
    }

    return sendResponse(res, 200, true, "User role updated successfully", user);
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Delete a user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin only)
// -----------------------------------------------
const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return sendResponse(res, 404, false, "User not found");
    }

    // Prevent admin from deleting themselves
    if (user._id.toString() === req.user._id.toString()) {
      return sendResponse(res, 400, false, "You cannot delete your own account");
    }

    await user.deleteOne();

    return sendResponse(res, 200, true, "User deleted successfully");
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllUsers, updateUserRole, deleteUser };
