// controllers/authController.js
// Handles user registration and login logic

const User = require("../models/User");
const generateToken = require("../utils/generateToken");
const sendResponse = require("../utils/sendResponse");

// -----------------------------------------------
// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
// -----------------------------------------------
const register = async (req, res, next) => {
  try {
    const { name, email, password, role } = req.body;

    // Check if a user with this email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return sendResponse(res, 400, false, "Email is already registered");
    }

    // Create the new user (password is hashed automatically by User model)
    const user = await User.create({ name, email, password, role });

    // Generate JWT token for the new user
    const token = generateToken(user._id, user.role);

    return sendResponse(res, 201, true, "Registration successful", {
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    next(error); // Pass to global error handler
  }
};

// -----------------------------------------------
// @desc    Login user and get token
// @route   POST /api/auth/login
// @access  Public
// -----------------------------------------------
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Find the user by email
    const user = await User.findOne({ email });

    // Check if user exists AND password matches
    if (!user || !(await user.matchPassword(password))) {
      return sendResponse(res, 401, false, "Invalid email or password");
    }

    // Generate JWT token
    const token = generateToken(user._id, user.role);

    return sendResponse(res, 200, true, "Login successful", {
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    next(error);
  }
};

// -----------------------------------------------
// @desc    Get current logged-in user profile
// @route   GET /api/auth/me
// @access  Private
// -----------------------------------------------
const getMe = async (req, res, next) => {
  try {
    // req.user is set by the authMiddleware
    return sendResponse(res, 200, true, "User profile fetched", {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      role: req.user.role,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { register, login, getMe };
