// middleware/authMiddleware.js
// This middleware protects routes — only logged-in users can access them
// It checks the JWT token sent in the request headers

const jwt = require("jsonwebtoken");
const User = require("../models/User");
const sendResponse = require("../utils/sendResponse");

const protect = async (req, res, next) => {
  let token;

  // JWT tokens are sent in the Authorization header as: "Bearer <token>"
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      // Extract the token part (remove "Bearer ")
      token = req.headers.authorization.split(" ")[1];

      // Verify the token using our secret key
      // If the token is invalid or expired, this will throw an error
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Find the user from the token's payload and attach to request
      // We exclude the password field for security
      req.user = await User.findById(decoded.id).select("-password");

      if (!req.user) {
        return sendResponse(res, 401, false, "User not found");
      }

      next(); // Move to the next middleware/controller
    } catch (error) {
      return sendResponse(res, 401, false, "Invalid or expired token");
    }
  }

  if (!token) {
    return sendResponse(res, 401, false, "Not authorized, no token provided");
  }
};

module.exports = { protect };
