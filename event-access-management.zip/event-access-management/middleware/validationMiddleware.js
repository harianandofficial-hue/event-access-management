// middleware/validationMiddleware.js
// Uses express-validator to check request data before it hits the controller
// If there are errors, we stop the request and send a 400 Bad Request response

const { validationResult } = require("express-validator");
const sendResponse = require("../utils/sendResponse");

const validate = (req, res, next) => {
  // Check if any validation errors exist (set by express-validator rules in routes)
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    // Format the errors into a simple array of messages
    const errorMessages = errors.array().map((err) => err.msg);
    return sendResponse(res, 400, false, errorMessages[0], {
      errors: errorMessages,
    });
  }

  next(); // No errors, continue to the controller
};

module.exports = { validate };
