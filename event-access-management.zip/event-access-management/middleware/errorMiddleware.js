// middleware/errorMiddleware.js
// Global error handler — catches all errors thrown anywhere in the app
// This must be the LAST middleware added in app.js (after all routes)

const errorHandler = (err, req, res, next) => {
  // Use the error's status code, or default to 500 (Internal Server Error)
  const statusCode = err.statusCode || res.statusCode || 500;

  // Log the error to console (helpful for debugging)
  console.error("❌ Error:", err.message);

  // Send a consistent error response
  res.status(statusCode).json({
    success: false,
    message: err.message || "Something went wrong on the server",
    // In development, also send the stack trace for debugging
    stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
  });
};

// 404 handler — for routes that don't exist
const notFound = (req, res, next) => {
  const error = new Error(`Route not found: ${req.originalUrl}`);
  error.statusCode = 404;
  next(error); // Pass to the error handler above
};

module.exports = { errorHandler, notFound };
