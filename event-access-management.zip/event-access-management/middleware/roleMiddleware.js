// middleware/roleMiddleware.js
// Role-Based Access Control (RBAC) middleware
// This checks if the logged-in user has the right role to access a route

const sendResponse = require("../utils/sendResponse");

// This is a "middleware factory" — you pass in allowed roles,
// and it returns a middleware function that checks the user's role.
//
// Usage in routes:
//   router.post("/events", protect, authorize("admin", "organizer"), createEvent)
//
const authorize = (...roles) => {
  return (req, res, next) => {
    // req.user is set by the authMiddleware (protect)
    // If the user's role is not in the allowed roles list, deny access
    if (!roles.includes(req.user.role)) {
      return sendResponse(
        res,
        403, // 403 = Forbidden
        false,
        `Access denied. Role '${req.user.role}' is not allowed to perform this action.`
      );
    }
    next(); // Role is allowed, continue
  };
};

module.exports = { authorize };
