// routes/registrationRoutes.js
// Defines URL paths for event registration and access verification

const express = require("express");

const {
  registerForEvent,
  getMyRegistrations,
  cancelRegistration,
  getEventAttendees,
  verifyTicket,
} = require("../controllers/registrationController");

const { protect } = require("../middleware/authMiddleware");
const { authorize } = require("../middleware/roleMiddleware");

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Registrations
 *   description: Event registration and access verification
 */

/**
 * @swagger
 * /registrations/my:
 *   get:
 *     summary: Get all events the logged-in user has registered for
 *     tags: [Registrations]
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: List of user's registrations
 */
router.get("/my", protect, getMyRegistrations);

/**
 * @swagger
 * /registrations/event/{eventId}:
 *   get:
 *     summary: Get all attendees for an event (Admin or Organizer only)
 *     tags: [Registrations]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: eventId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: List of attendees
 *       403:
 *         description: Access denied
 */
router.get(
  "/event/:eventId",
  protect,
  authorize("admin", "organizer"),
  getEventAttendees
);

/**
 * @swagger
 * /registrations/verify/{ticketId}:
 *   patch:
 *     summary: Verify attendee entry using ticket ID (check-in)
 *     tags: [Registrations]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: ticketId
 *         required: true
 *         schema:
 *           type: string
 *         description: The UUID ticket ID from the registration
 *     responses:
 *       200:
 *         description: Check-in successful
 *       400:
 *         description: Ticket already used
 *       404:
 *         description: Invalid ticket ID
 */
router.patch(
  "/verify/:ticketId",
  protect,
  authorize("admin", "organizer"),
  verifyTicket
);

/**
 * @swagger
 * /registrations/{eventId}:
 *   post:
 *     summary: Register for an event
 *     tags: [Registrations]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: eventId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       201:
 *         description: Registered successfully, returns ticket ID
 *       400:
 *         description: Already registered or event is full
 *       404:
 *         description: Event not found
 */
router.post("/:eventId", protect, registerForEvent);

/**
 * @swagger
 * /registrations/{registrationId}:
 *   delete:
 *     summary: Cancel a registration
 *     tags: [Registrations]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: registrationId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Registration cancelled
 *       403:
 *         description: Not authorized
 *       404:
 *         description: Registration not found
 */
router.delete("/:registrationId", protect, cancelRegistration);

module.exports = router;
