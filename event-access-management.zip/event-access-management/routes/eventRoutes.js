// routes/eventRoutes.js
// Defines the URL paths for event management

const express = require("express");
const { body } = require("express-validator");

const {
  createEvent,
  getAllEvents,
  getEventById,
  updateEvent,
  deleteEvent,
} = require("../controllers/eventController");

const { protect } = require("../middleware/authMiddleware");
const { authorize } = require("../middleware/roleMiddleware");
const { validate } = require("../middleware/validationMiddleware");

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Events
 *   description: Event management endpoints
 */

/**
 * @swagger
 * /events:
 *   get:
 *     summary: Get all events
 *     tags: [Events]
 *     security: []
 *     responses:
 *       200:
 *         description: List of all events
 */
router.get("/", getAllEvents);

/**
 * @swagger
 * /events/{id}:
 *   get:
 *     summary: Get a single event by ID
 *     tags: [Events]
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Event details
 *       404:
 *         description: Event not found
 */
router.get("/:id", getEventById);

/**
 * @swagger
 * /events:
 *   post:
 *     summary: Create a new event (Admin or Organizer only)
 *     tags: [Events]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [title, description, date, venue]
 *             properties:
 *               title:
 *                 type: string
 *                 example: Tech Conference 2025
 *               description:
 *                 type: string
 *                 example: Annual technology conference
 *               date:
 *                 type: string
 *                 format: date
 *                 example: "2025-12-15"
 *               venue:
 *                 type: string
 *                 example: City Convention Center
 *               capacity:
 *                 type: number
 *                 example: 200
 *     responses:
 *       201:
 *         description: Event created successfully
 *       403:
 *         description: Access denied
 */
router.post(
  "/",
  protect,
  authorize("admin", "organizer"),
  [
    body("title").notEmpty().withMessage("Title is required"),
    body("description").notEmpty().withMessage("Description is required"),
    body("date").isISO8601().withMessage("Please enter a valid date"),
    body("venue").notEmpty().withMessage("Venue is required"),
  ],
  validate,
  createEvent
);

/**
 * @swagger
 * /events/{id}:
 *   put:
 *     summary: Update an event (Admin or Organizer who created it)
 *     tags: [Events]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *               description:
 *                 type: string
 *               venue:
 *                 type: string
 *               capacity:
 *                 type: number
 *     responses:
 *       200:
 *         description: Event updated
 *       403:
 *         description: Not authorized
 *       404:
 *         description: Event not found
 */
router.put("/:id", protect, authorize("admin", "organizer"), updateEvent);

/**
 * @swagger
 * /events/{id}:
 *   delete:
 *     summary: Delete an event (Admin or Organizer who created it)
 *     tags: [Events]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Event deleted
 *       403:
 *         description: Not authorized
 *       404:
 *         description: Event not found
 */
router.delete("/:id", protect, authorize("admin", "organizer"), deleteEvent);

module.exports = router;
